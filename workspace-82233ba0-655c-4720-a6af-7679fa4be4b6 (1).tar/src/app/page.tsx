'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Menu, X, Shield, Mail, Phone, MessageCircle, Clock, MapPin, Send, Star, Trophy, HeadphonesIcon, MapPin as LocationIcon, Award } from 'lucide-react'

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [chatOpen, setChatOpen] = useState(false)
  const [chatMessage, setChatMessage] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitMessage, setSubmitMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    propertyType: '',
    requirements: ''
  })

  const services = [
    {
      icon: Shield,
      title: 'CCTV System',
      description: 'Complete security setup for surveillance footage capture and review with high-definition cameras and remote monitoring.'
    },
    {
      icon: Shield,
      title: 'Fire Alarm System',
      description: 'Advanced smoke, heat, and flame detection for emergency response with automated alerts.'
    },
    {
      icon: Shield,
      title: 'Attendance System (Bio-Face)',
      description: 'Biometric facial recognition for employee attendance tracking with real-time reporting.'
    },
    {
      icon: Shield,
      title: 'Access Control System',
      description: 'Secure entry management through cards, biometrics, or facial recognition for controlled access.'
    },
    {
      icon: Phone,
      title: 'EPABX/Intercom System',
      description: 'Efficient internal communication solutions for organizations with seamless connectivity.'
    },
    {
      icon: Shield,
      title: 'Computer Networking',
      description: 'Connecting devices for data sharing and business continuity with robust infrastructure.'
    },
    {
      icon: Shield,
      title: 'Audio & Video Conferencing',
      description: 'Real-time communication tools for virtual meetings and presentations.'
    },
    {
      icon: Shield,
      title: 'Video Door Phone System',
      description: 'Secure access solutions with visitor verification through video/audio communication.'
    },
    {
      icon: Shield,
      title: 'Electronic Door Lock/EM Lock',
      description: 'Advanced locking systems with electric current and authentication for maximum security.'
    },
    {
      icon: Shield,
      title: 'Card Lock/Password Lock',
      description: 'Entry solutions combining convenience and security through cards or codes.'
    },
    {
      icon: Shield,
      title: 'Home Automation',
      description: 'Smart systems for lighting, security, appliances, and climate control for modern living.'
    },
    {
      icon: Shield,
      title: 'ERP Software',
      description: 'All-in-one digital solution for academics, administration, and finances.'
    }
  ]

  const testimonials = [
    {
      name: 'Jyoti Sharma',
      company: 'Yatharth',
      text: 'Vunity Solutions transformed our office security with their CCTV and access control systems. The installation was seamless, and the support team has been extremely responsive. We feel safer and more in control of our premises.'
    },
    {
      name: 'Arvind Chodhary',
      company: 'B-Mart',
      text: 'Their home automation solutions have made our living space smarter and more efficient. We now control lighting, temperature, and security with ease. The team was professional and attentive to every detail.'
    },
    {
      name: 'Khemendra Sharma',
      company: 'AIM Placement',
      text: 'The IT infrastructure setup for our business was completed on time and without disruption. Vunity Solutions\' expertise and guidance helped us upgrade smoothly, and their AMC service ensures everything runs perfectly.'
    },
    {
      name: 'Aashish Sharma',
      company: 'Factory Supervisor',
      text: 'The IP Cameras Setup installed by Vunity Solutions has given us peace of mind. Knowing that safety measures are in place and regularly maintained makes our environment more secure.'
    }
  ]

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
      setMobileMenuOpen(false)
    }
  }

  const openWhatsAppChat = () => {
    const message = encodeURIComponent(chatMessage || 'Hello, I am interested in your security solutions.')
    window.open(`https://wa.me/918005702022?text=${message}`, '_blank')
    setChatOpen(false)
    setChatMessage('')
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setSubmitMessage(null)

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (data.success) {
        setSubmitMessage({ type: 'success', text: 'Thank you! Your request has been submitted successfully. We will contact you soon.' })
        setFormData({ name: '', phone: '', propertyType: '', requirements: '' })
      } else {
        setSubmitMessage({ type: 'error', text: 'Failed to submit your request. Please try again or contact us directly.' })
      }
    } catch (error) {
      console.error('Error submitting form:', error)
      setSubmitMessage({ type: 'error', text: 'Failed to submit your request. Please try again or contact us directly.' })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <img
                src="/logo.jpg"
                alt="Vunity Solutions Logo"
                className="h-10 w-auto"
              />
              <span className="text-xl md:text-2xl font-bold text-primary">Vunity Solutions</span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex space-x-8">
              <button onClick={() => scrollToSection('home')} className="text-foreground hover:text-primary transition-colors">Home</button>
              <button onClick={() => scrollToSection('services')} className="text-foreground hover:text-primary transition-colors">Services</button>
              <button onClick={() => scrollToSection('about')} className="text-foreground hover:text-primary transition-colors">About Us</button>
              <button onClick={() => scrollToSection('testimonials')} className="text-foreground hover:text-primary transition-colors">Testimonials</button>
              <button onClick={() => scrollToSection('contact')} className="text-foreground hover:text-primary transition-colors">Contact</button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 space-y-2">
              <button onClick={() => scrollToSection('home')} className="block w-full text-left py-2 px-4 hover:bg-accent rounded">Home</button>
              <button onClick={() => scrollToSection('services')} className="block w-full text-left py-2 px-4 hover:bg-accent rounded">Services</button>
              <button onClick={() => scrollToSection('about')} className="block w-full text-left py-2 px-4 hover:bg-accent rounded">About Us</button>
              <button onClick={() => scrollToSection('testimonials')} className="block w-full text-left py-2 px-4 hover:bg-accent rounded">Testimonials</button>
              <button onClick={() => scrollToSection('contact')} className="block w-full text-left py-2 px-4 hover:bg-accent rounded">Contact</button>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="py-16 md:py-24 lg:py-32 bg-gradient-to-br from-primary/10 via-background to-primary/5">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-5xl mx-auto text-center">
            <img
              src="/logo.jpg"
              alt="Vunity Solutions Logo"
              className="h-20 w-auto mx-auto mb-8"
            />
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Secure Your World with<br />
              <span className="text-primary">Vunity Solutions</span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-6">
              Professional CCTV & Security Systems in Jagatpura, Jaipur.
            </p>
            <p className="text-lg text-muted-foreground mb-8">
              Trusted since 2015 with 4.8★ rating from 27,000+ satisfied customers.
            </p>
            <div className="flex flex-wrap gap-4 justify-center mb-12">
              <Button
                size="lg"
                onClick={() => scrollToSection('contact-form')}
                className="text-lg px-8"
              >
                📞 Get Free Quote
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => scrollToSection('services')}
                className="text-lg px-8"
              >
                🔍 Our Services
              </Button>
            </div>

            {/* Key Highlights */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">9+</div>
                <div className="text-muted-foreground">Years Experience</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">4.8★</div>
                <div className="text-muted-foreground">Average Rating</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">27,000+</div>
                <div className="text-muted-foreground">Happy Customers</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">2015</div>
                <div className="text-muted-foreground">Established</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="py-12 bg-muted/30 border-y">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-8 md:gap-16 text-center">
            <div className="flex items-center gap-3">
              <Trophy className="w-8 h-8 text-primary" />
              <div className="text-left">
                <div className="font-semibold">9+ Years Experience</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-primary" />
              <div className="text-left">
                <div className="font-semibold">24/7 Support</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <LocationIcon className="w-8 h-8 text-primary" />
              <div className="text-left">
                <div className="font-semibold">Local Expertise</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section id="about" className="py-16 md:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">About Vunity Solutions</h2>
            </div>

            <div className="prose prose-lg max-w-4xl mx-auto mb-12">
              <p className="text-lg text-muted-foreground leading-relaxed">
                At Vunity Solutions, we empower businesses, homes, and institutions with innovative technology solutions that enhance security, efficiency, and productivity. Specializing in security systems, IT infrastructure, communication networks, and automation, we deliver tailored services in partnership with leading technology providers.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Our expert team ensures seamless planning, installation, and ongoing support, including AMC services to maintain peak system performance. With reliability and customer satisfaction at our core, Vunity Solutions is your trusted partner for smarter, safer, and more efficient operations.
              </p>
            </div>

            {/* Why Choose Us */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
              <Card className="text-center">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <Trophy className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">9+ Years Experience</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>Established in 2015, we bring nearly a decade of expertise in security technology.</CardDescription>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <Star className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">4.8★ Customer Rating</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>Consistently high ratings from 27,000+ satisfied customers across Jaipur.</CardDescription>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <Award className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">Cost-Effective Solutions</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>Quality security systems at competitive prices with excellent after-sales support.</CardDescription>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <LocationIcon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">Local Expertise</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>Deep understanding of Jaipur's security needs and local regulations.</CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-16 md:py-24 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Security Solutions</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Comprehensive CCTV and security systems for homes, offices, and educational institutions
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
            {services.map((service, index) => {
              const Icon = service.icon
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow flex flex-col">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <CardDescription className="text-base mb-4">
                      {service.description}
                    </CardDescription>
                    <Button variant="link" className="px-0 text-primary" onClick={() => scrollToSection('contact-form')}>
                      Learn More →
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-16 md:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Clients Say</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Trusted by thousands of satisfied customers across Jaipur
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8 mb-12 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">27,000+</div>
              <div className="text-muted-foreground">Happy Customers</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">4.8★</div>
              <div className="text-muted-foreground">Average Rating</div>
            </div>
            <div className="text-center col-span-2 md:col-span-1">
              <div className="flex items-center justify-center gap-1 text-yellow-500 text-2xl mb-2">
                <Star fill="currentColor" />
                <Star fill="currentColor" />
                <Star fill="currentColor" />
                <Star fill="currentColor" />
                <Star fill="currentColor" />
              </div>
              <div className="text-muted-foreground">★★★★★</div>
            </div>
          </div>

          {/* Testimonial Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{testimonial.name}</CardTitle>
                      <CardDescription>{testimonial.company}</CardDescription>
                    </div>
                    <div className="flex items-center gap-1 text-yellow-500">
                      <Star fill="currentColor" className="w-4 h-4" />
                      <Star fill="currentColor" className="w-4 h-4" />
                      <Star fill="currentColor" className="w-4 h-4" />
                      <Star fill="currentColor" className="w-4 h-4" />
                      <Star fill="currentColor" className="w-4 h-4" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground italic">"{testimonial.text}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quote Request Form Section */}
      <section id="contact-form" className="py-16 md:py-24 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Get Your Free Security Consultation</h2>
              <p className="text-xl text-muted-foreground">
                Ready to secure your property? Contact us today for a personalized security assessment and quote.
              </p>
            </div>

            <Card>
              <CardContent className="p-6 md:p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="Enter your full name"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="Enter your phone number"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="propertyType">Property Type *</Label>
                    <Input
                      id="propertyType"
                      type="text"
                      placeholder="Select property type (Home/Office/Factory/School, etc.)"
                      required
                      value={formData.propertyType}
                      onChange={(e) => setFormData({ ...formData, propertyType: e.target.value })}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="requirements">Security Requirements</Label>
                    <Textarea
                      id="requirements"
                      placeholder="Describe your security needs (number of cameras, areas to cover, etc.)"
                      rows={4}
                      value={formData.requirements}
                      onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
                      className="mt-2"
                    />
                  </div>

                  {submitMessage && (
                    <div
                      className={`p-4 rounded-lg ${
                        submitMessage.type === 'success'
                          ? 'bg-green-50 text-green-800 border border-green-200'
                          : 'bg-red-50 text-red-800 border border-red-200'
                      }`}
                    >
                      {submitMessage.text}
                    </div>
                  )}

                  <Button
                    type="submit"
                    size="lg"
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Submitting...' : 'Submit Request'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 md:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Contact Information</h2>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Contact Information */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-semibold mb-6">Location</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium">Jagatpura Getor, Jaipur, Rajasthan</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-semibold mb-6">Phone</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Phone className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium">Call for immediate assistance</div>
                        <a href="tel:+918005702022" className="text-primary hover:underline text-lg">
                          +91 80057 02022
                        </a>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-semibold mb-6">Email</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Mail className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium">Send us your queries</div>
                        <a href="mailto:vunitysolutions@gmail.com" className="text-primary hover:underline">
                          vunitysolutions@gmail.com
                        </a>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-semibold mb-6">Business Hours</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Clock className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium">Mon - Sat: 9:00 AM - 6:00 PM</div>
                        <div className="text-muted-foreground">Sunday: Closed</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Emergency Support */}
            <Card className="mt-6 border-2 border-primary/20">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                      <HeadphonesIcon className="w-6 h-6 text-red-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">Emergency Support</h3>
                      <p className="text-muted-foreground mb-3">
                        Need urgent security assistance? We provide 24/7 emergency support for existing customers.
                      </p>
                      <Button
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => window.open('https://wa.me/918005702022', '_blank')}
                      >
                        <MessageCircle className="w-5 h-5 mr-2" />
                        WhatsApp Emergency Contact
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* JustDial Review Link */}
            <Card className="mt-6 bg-blue-50/50 border-blue-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between gap-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                      <Star className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">Check Our Reviews</h3>
                      <p className="text-muted-foreground">
                        See what our customers say about us on JustDial
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    className="bg-white hover:bg-blue-50 border-blue-300 text-blue-700"
                    onClick={() => window.open('https://www.justdial.com/Jaipur/Vunity-Solutions-Jagatpura-Getor/0141PX141-X141-141016084501-S9H4_BZDET?auto=1&trkid=3047182813&term=', '_blank')}
                  >
                    <Star className="w-5 h-5 mr-2" />
                    View on JustDial
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* WhatsApp Chat Widget */}
      <div className="fixed bottom-6 right-6 z-50">
        {chatOpen ? (
          <div className="bg-white rounded-lg shadow-2xl w-80 sm:w-96 border">
            {/* Chat Header */}
            <div className="bg-green-600 text-white p-4 rounded-t-lg flex items-center justify-between">
              <div className="flex items-center gap-3">
                <MessageCircle className="w-6 h-6" />
                <div>
                  <div className="font-semibold">WhatsApp Chat</div>
                  <div className="text-xs opacity-90">Vunity Solutions</div>
                </div>
              </div>
              <button
                onClick={() => setChatOpen(false)}
                className="p-1 hover:bg-green-700 rounded"
                aria-label="Close chat"
              >
                <X size={20} />
              </button>
            </div>

            {/* Chat Body */}
            <div className="p-4 h-64 bg-gray-50">
              <div className="bg-white p-3 rounded-lg shadow-sm mb-3">
                <p className="text-sm">Hello! 👋 Welcome to Vunity Solutions. How can we help you today?</p>
                <span className="text-xs text-gray-500">Just now</span>
              </div>
            </div>

            {/* Chat Input */}
            <div className="p-4 border-t">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      openWhatsAppChat()
                    }
                  }}
                />
                <Button
                  onClick={openWhatsAppChat}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Send size={20} />
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-2 text-center">
                Start a conversation on WhatsApp
              </p>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setChatOpen(true)}
            className="bg-green-600 hover:bg-green-700 text-white p-4 rounded-full shadow-lg transition-all hover:scale-110"
            aria-label="Open WhatsApp chat"
          >
            <MessageCircle size={28} />
          </button>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-muted/50 border-t mt-auto">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <img
                  src="/logo.jpg"
                  alt="Vunity Solutions Logo"
                  className="h-12 w-auto"
                />
                <h3 className="text-2xl font-bold">Vunity Solutions</h3>
              </div>
              <p className="text-muted-foreground mb-6">
                Your trusted partner for CCTV and security solutions in Jaipur since 2015.
              </p>
              <div className="flex items-center gap-2 text-yellow-500 mb-4">
                <Star fill="currentColor" className="w-5 h-5" />
                <span className="text-foreground font-semibold">4.8/5 from 27,000+ customers</span>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <div className="space-y-2">
                <button onClick={() => scrollToSection('home')} className="block text-muted-foreground hover:text-primary transition-colors">Home</button>
                <button onClick={() => scrollToSection('services')} className="block text-muted-foreground hover:text-primary transition-colors">Services</button>
                <button onClick={() => scrollToSection('about')} className="block text-muted-foreground hover:text-primary transition-colors">About Us</button>
                <button onClick={() => scrollToSection('contact')} className="block text-muted-foreground hover:text-primary transition-colors">Contact</button>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Follow Us</h3>
              <div className="flex items-center gap-3 mb-4">
                <Button
                  variant="outline"
                  size="icon"
                  className="rounded-full"
                  onClick={() => window.open('https://www.facebook.com/Vunitysolutions', '_blank')}
                >
                  <span className="text-blue-600 font-bold">f</span>
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  className="rounded-full"
                  onClick={() => window.open('https://www.instagram.com/vunitysolutions/', '_blank')}
                >
                  <span className="text-pink-600 font-bold">i</span>
                </Button>
              </div>
              <div className="flex items-center gap-3 mb-4">
                <Button
                  variant="outline"
                  className="flex-1 bg-blue-50 hover:bg-blue-100 border-blue-200"
                  onClick={() => window.open('https://www.justdial.com/Jaipur/Vunity-Solutions-Jagatpura-Getor/0141PX141-X141-141016084501-S9H4_BZDET?auto=1&trkid=3047182813&term=', '_blank')}
                >
                  <Star className="w-4 h-4 mr-2 text-blue-600" />
                  <span className="text-sm">JustDial Reviews</span>
                </Button>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span>Jagatpura, Jaipur</span>
              </div>
            </div>
          </div>

          <div className="border-t mt-8 pt-8 text-center text-muted-foreground text-sm">
            <p>© 2024 Vunity Solutions. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
